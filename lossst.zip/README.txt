Wam jam 2023 game
===

All rights reserved


Track list:

- 1: Edvard Grieg - Peer Gynt Suite No. 1, Op. 46 - I. Morning Mood
- 2: Tchaikovski - The Nutcracker: Suite no. 1: Dance of the Mirlitons / reed flutes
- 3: Wolfgang Amadeus Mozart - Sonata No. 11 in A Major for Piano. K.331-III (Rondo) - Alla Turca Allegretto
- 4: Wolfgang Amadeus Mozart - Serenade in G, K.525, "Eine Kleine Nachtmusik" Allegro
- 5: Antonio Vivaldi - Concerto for Volin and Strings in E, Op. 8, N°1, RV.269 - "La Primavera"
- 6: Edvard Grieg - Peer Gynt Suite No. 1, Op. 46 - IV. In the Hall Of The Mountain King
- 7: Georges Bizet - L'arlésienne suite No.2. IV: Farandole
- 8: Ludwig van Beethoven - Für Elise, WoO 59
- 9: Johann Sebastien Bach - Bwv1067 Orchestral Suite No. 2 - Badinerie
- 10: Johann Strauss - Blue Danube