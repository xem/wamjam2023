all rights served to the copyright holder

distribution rights granted to js13kgames.com
