// World 1

  [
    
      // Floor
      [
        0b1000000,
        0b1001000,
        0b1001110,
        0b1000110
      //0b1000000
      ],
      
      // Wall
      ,
      
      // Width
      5,
      
      // Height
      ,
      
      // Snake length
      6,
      
      // Hint
      
      // Bricks
    
    ],
    
    [
    
      // Floor
      [
        0b1000000,
        0b1000010,
        0b1000110,
        0b1000110,
        0b1001110
      //0b1000000
      ],
      
      // Wall
      ,
      
      // Width
      5,
      
      // Height
      6,
      
      // Snake length
      8,
      
      // Hint
      
      // Bricks
    
    ],
    
    [
    
      // Floor
      [
        0b1000000,
        0b0000010,
        0b0000110,
        0b1000110,
        0b1000110,
        0b1000100
      //0b1000000
      ],
      
      // Wall
      ,
      
      // Width
      4,
      
      // Height
      7,
      
      // Snake length
      8,
      
      // Hint
      
      // Bricks
    
    ],
    
    [
    
      // Floor
      [
        0b1000111,
        0b1000010,
        0b1000011
      ],
      
      // Wall
      ,
      
      // Width
      3,
      
      // Height
      ,
      
      // Snake length
      9,
      
      // Hint
      ,
      
      // Bricks
      [[0,1]]
    
    ],
    
    
    // Puzzle 22
    [
    
      // Floor
      [
        0b1000100,
        0b1001111,
        0b1001110,
        0b1001100
      ],
      
      // Wall
      ,
      
      // Width
      4,
      
      // Height
      ,
      
      // Snake length
      10,
      
      // Hint
      
      
      // Bricks
    ],
    
    [
    
      // Floor
      [
        0b1000111,
        0b1000101,
        0b1001111,
        0b1001100
      ],
      
      // Wall
      ,
      
      // Width
      4,
      
      // Height
      ,
      
      // Snake length
      11,
      
      // Hint
      
      
      // Bricks
      
    ],
    
    
    [
    
      // Floor
      [
        0b1000000,
        0b1011110,
        0b1011100,
        0b1011110
      //0b1000000
      ],
      
      // Wall
      ,
      
      // Width
      6,
      
      // Height
      5,
      
      // Snake length
      11,
      
      // Hint
      
      
      // Bricks
      
    ],
    

    [
    
      // Floor
      [
        0b1000101,
        0b1000111,
        0b1000011,
        0b1000001
      ],
      
      // Wall
      ,
      
      // Width
      4,
      
      // Height
      ,
      
      // Snake length
      11,
      
      // Hint
      ,
      
      // Bricks
      [[1,0],[3,0]]
    ],
    
    
    [
    
      // Floor
      [
        0b1000110,
        0b1001111,
        0b1001111,
        0b1000110
      ],
      
      // Wall
      ,
      
      // Width
      4,
      
      // Height
      ,
      
      // Snake length
      12,
      
      // Hint
      
      
      // Bricks
      
    ],
    
    
    [
    
      // Floor
      ,
      
      // Wall
      [
        0b1000000,
        0b1011111,
        0b1011101,
        0b1010111,
        0b1011100
      ],
      
      // Width
      5,
      
      // Height
      ,
      
      // Snake length
      16,
      
      // Hint
      
      
      // Bricks
      
    ],